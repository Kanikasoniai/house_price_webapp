from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model
model = joblib.load('model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get values from the form
        grlivarea = float(request.form['GrLivArea'])
        bedroom = int(request.form['BedroomAbvGr'])
        fullbath = int(request.form['FullBath'])

        # Make prediction
        features = [[grlivarea, bedroom, fullbath]]
        predicted_price = model.predict(features)[0]

        # Format price with commas
        formatted_price = f"{predicted_price:,.0f}"

        # Send to result page
        return render_template('result.html', prediction=formatted_price)

    except Exception as e:
        return f"❌ Error occurred: {e}"

if __name__ == '__main__':
    app.run(debug=True)


